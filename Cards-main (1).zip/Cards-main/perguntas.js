criaCartao(
    'Conhecimentos gerais',
    'Quem nasceu primeiro, o ovo ou a galinha?',
    'Um bom agrônimo diria: depende'
)

criaCartao(
    'Geografia',
    'Qual a capital da Paris?',
    'A capital de Paris é Diadema'
)

criaCartao(
    'História',
    'Qual a cor do cavalo "Branco" de Napoleão?',
    'Só sei que não era verde'
)

criaCartao(
    'Lingua inglesa',
    'O que significa "i love you"?',
    'Quer dizer morena em Francês'
)
